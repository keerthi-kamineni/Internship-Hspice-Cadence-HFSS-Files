.param   TEMP=27

*Include relevant model files
.include /home/vlsi/Desktop/my_work/CNFET.lib 


* Power Supply
Vdd1 vdd1 Gnd 0.7V
Vdd2 vdd2 Gnd 0.7V
Vin1 in1 Gnd PULSE(0 0.7 0n 100p 100p 1200p 2000p)
Vin2 in2 Gnd PULSE(0.7 0 0n 100p 100p 1200p 2000p)

* Main Circuits

* CNFET Circuit
X11 aa1 in1 vdd1 vdd1 PCNFET  
X21 aa1 in1 Gnd Gnd NCNFET 
X12 aa2 in2 vdd2 vdd2 PCNFET  
X22 aa2 in2 Gnd Gnd NCNFET 
 
*Contact Resistance
Rc1 aa1 a1 200 
Rc2 aa2 a2 200

Cload1 out1 0 200a
Cload2 out2 0 200a

Cui a1 a2 2.4449a
Cub out1 out2 2.4427a

Rsi g1 g2 0.477u
Csi g1 g2 5.033a

Rvia1 a1 b1 2.9905
Rvia2 d1 out1 2.9905
Rvia3 a2 b2 2.9905
Rvia4 d2 out2 2.9905

Lvia1 b1 c1 2.35055f 
Lvia2 c1 d1 2.35055f 
Lvia3 b2 c2 2.35055f 
Lvia4 c2 d2 2.35055f 

Ctsv1 c1 g1 19.84a
Ctsv2 c2 g2 19.84a

Rshort1 c1 g1 25.133n
Rshort2 c2 g2 25.133n

Cshort1 c1 g1 25.844a
Cshort2 c2 g2 25.844a

.tran 0.002n 12n
* Power and Current Measurements
.measure tran dynamic_power avg power from=0ps to=2000ps  
.measure tran SupplyCurrent avg i(Vdd1) from=0ps to=2000ps  
.measure tran static_power PARAM='-SupplyCurrent*0.7'  

.measure I_Rsi avg i(Rsi) from=0ps to=2000ps

.measure V_Rsi avg V(g1,g2) from=0ps to=2000ps

.measure tran power_Rsi PARAM='I_Rsi*V_Rsi' 

*Peak noise 
.measure TRAN peak_noise_out1 MAX V(out1) from=0ps to=2000ps
* Crosstalk Delay Measurements

.measure tran xtalk_delay12_a trig v(in1) val=0.35 rise=1 targ v(out2) val=0.35 fall=1  
.measure tran xtalk_delay12_b trig v(in1) val=0.35 fall=1 targ v(out2) val=0.35 rise=1  
.measure TRAN t_crosstalk_delay12 PARAM = '(abs(xtalk_delay12_a) + abs(xtalk_delay12_b)) / 2' 

.measure tran xtalk_delay21_a trig v(in2) val=0.35 rise=1 targ v(out1) val=0.35 fall=1  
.measure tran xtalk_delay21_b trig v(in2) val=0.35 fall=1 targ v(out1) val=0.35 rise=1  
.measure TRAN t_crosstalk_delay21 PARAM = '(abs(xtalk_delay21_a) + abs(xtalk_delay21_b)) / 2'

.plot V(in1) V(out1) V(out2)
.option PROBE POST=2 MEASOUT 
.option measform=3
.option measfile=1
.end  

