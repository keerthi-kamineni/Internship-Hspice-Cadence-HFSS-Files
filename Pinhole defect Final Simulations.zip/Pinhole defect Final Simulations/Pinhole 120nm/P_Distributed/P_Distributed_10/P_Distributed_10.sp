.param   TEMP=27

*Include relevant model files
.include /home/vlsi/Desktop/my_work/CNFET.lib


* Power Supply
Vdd1 vdd1 Gnd 0.7V
Vdd2 vdd2 Gnd 0.7V
Vin1 in1 Gnd PULSE(0 0.7 0n 100p 100p 1200p 2000p)
Vin2 in2 Gnd PULSE(0 0.7 0n 100p 100p 1200p 2000p)

* Main Circuits

* CNFET Circuit
X11 aa1 in1 vdd1 vdd1 PCNFET  
X21 aa1 in1 Gnd Gnd NCNFET 
X12 aa2 in2 vdd2 vdd2 PCNFET  
X22 aa2 in2 Gnd Gnd NCNFET 
 
*Contact Resistance
Rc1 aa1 o1 200 
Rc2 aa2 o2 200

Cload1 out1 0 200a
Cload2 out2 0 200a

.subckt rlgc a1 out10 a2 out20 

* SUBCIRCUIT circuit 


Cui a1 a2 2.4449a
Cub out10 out20 2.4427a

Rsi g1 g2 0.576u
Csi g1 g2 6.012a

Rvia1 a1 b1 2.9905
Rvia2 d1 out10 2.9905
Rvia3 a2 b2 2.9905
Rvia4 d2 out20 2.9905

Lvia1 b1 c1 2.35055f 
Lvia2 c1 d1 2.35055f 
Lvia3 b2 c2 2.35055f 
Lvia4 c2 d2 2.35055f 

Ctsv1 c1 g1 22.62a
Ctsv2 c2 g2 22.62a

Rshort1 c1 g1 17.74n
Rshort2 c2 g2 17.74n

Cshort1 c1 g1 30.77a
Cshort2 c2 g2 30.77a

* end of subcircuit ***
.ends

* main code for 10 distribution 
* calling of subcircuit*

Xrlgc1 o1 p1 o2 p2 rlgc
Xrlgc2 p1 q1 p2 q2 rlgc
Xrlgc3 q1 r1 q2 r2 rlgc
Xrlgc4 r1 s1 r2 s2 rlgc
Xrlgc5 s1 t1 s2 t2 rlgc
Xrlgc6 t1 u1 t2 u2 rlgc
Xrlgc7 u1 v1 u2 v2 rlgc
Xrlgc8 v1 w1 v2 w2 rlgc
Xrlgc9 w1 x1 w2 x2 rlgc
Xrlgc10 x1 out1 x2 out2 rlgc



.tran 0.002n 12n
* Power and Current Measurements
.measure tran dynamic_power avg power from=0ps to=2000ps  
.measure tran SupplyCurrent avg i(Vdd1) from=0ps to=2000ps  
.measure tran static_power PARAM='-SupplyCurrent*0.7'  

.measure I_Rsi avg i(Rsi) from=0ps to=2000ps

.measure V_Rsi avg V(g1,g2) from=0ps to=2000ps

.measure tran power_Rsi PARAM='I_Rsi*V_Rsi' 

*Peak noise 
.measure TRAN peak_noise_out1 MAX V(out1) from=0ps to=2000ps
* Propagation Delay Measurements
.measure tran tpLH1 trig v(in1) val=0.35 rise=1 targ v(out1) val=0.35 fall=1  
.measure tran tpHL1 trig v(in1) val=0.35 fall=1 targ v(out1) val=0.35 rise=1  
.measure TRAN t_propagation_delay1 PARAM = '(abs(tpLH1) + abs(tpHL1)) / 2' 

.measure tran tpLH2 trig v(in2) val=0.35 rise=1 targ v(out2) val=0.35 fall=1  
.measure tran tpHL2 trig v(in2) val=0.35 fall=1 targ v(out2) val=0.35 rise=1  
.measure TRAN t_propagation_delay2 PARAM = '(abs(tpLH2)+abs(tpHL2))/2'


.plot V(in1) V(out1) V(out2)
.option PROBE POST=2 MEASOUT 
.option measform=3
.option measfile=1
.end  

